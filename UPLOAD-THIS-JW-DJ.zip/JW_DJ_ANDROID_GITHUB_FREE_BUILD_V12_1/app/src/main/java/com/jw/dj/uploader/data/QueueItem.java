package com.jw.dj.uploader.data;

public class QueueItem {
    public long id;
    public String uri;
    public String name;
    public String relativePath;
    public long size;
    public String mime;
    public long modified;
    public String transferId;
    public String cloudId;
    public String fingerprint;
    public String status;
    public String uploadedChunks;
    public int totalChunks;
    public boolean safeDelete;
    public String error;
    public long createdAt;
    public long updatedAt;
}
