package com.jw.dj.uploader.transfer;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.jw.dj.uploader.data.QueueDatabase;
import com.jw.dj.uploader.util.Prefs;

public final class TransferScheduler {
    public static final int JOB_ID = 120012;
    private TransferScheduler() {}

    public static boolean start(Context c) {
        Prefs.setPaused(c, false);
        if (Build.VERSION.SDK_INT >= 34) {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            QueueDatabase db = new QueueDatabase(c);
            JobInfo info = new JobInfo.Builder(JOB_ID, new ComponentName(c, NativeTransferJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setUserInitiated(true)
                    .setEstimatedNetworkBytes(0L, Math.max(1L, db.pendingBytes()))
                    .build();
            return js.schedule(info) == JobScheduler.RESULT_SUCCESS;
        } else {
            Intent i = new Intent(c, LegacyForegroundUploadService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
            return true;
        }
    }

    public static void pause(Context c) {
        Prefs.setPaused(c, true);
        if (Build.VERSION.SDK_INT >= 34) {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            js.cancel(JOB_ID);
        }
        c.stopService(new Intent(c, LegacyForegroundUploadService.class));
    }
}
