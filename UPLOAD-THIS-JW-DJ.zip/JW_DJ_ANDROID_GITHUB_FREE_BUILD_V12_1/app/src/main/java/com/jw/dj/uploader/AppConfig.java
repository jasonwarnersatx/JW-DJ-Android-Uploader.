package com.jw.dj.uploader;

public final class AppConfig {
    private AppConfig() {}

    public static final String DEFAULT_SERVER = "https://jwdjsystem.netlify.app";
    // Must match the existing V11.9 web uploader exactly.
    public static final int CHUNK_BYTES = 3_584 * 1_024;
    public static final int TURBO_LANES = 4;
    public static final int PLAYING_LANES = 1;
    public static final String PHONE_IMPORT_FOLDER = "Music/Phone Imports";

    public static final String PREFS = "jw_native_uploader";
    public static final String PREF_SERVER = "server_url";
    public static final String PREF_UPLOAD_KEY = "upload_key";
    public static final String PREF_TREE_URI = "tree_uri";
    public static final String PREF_PAUSED = "paused";

    public static final String ACTION_PROGRESS = "com.jw.dj.uploader.PROGRESS";
    public static final String EXTRA_MESSAGE = "message";
}
