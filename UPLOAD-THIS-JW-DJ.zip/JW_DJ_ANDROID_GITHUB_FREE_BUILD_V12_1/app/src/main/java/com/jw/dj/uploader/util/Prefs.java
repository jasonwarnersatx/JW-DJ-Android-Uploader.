package com.jw.dj.uploader.util;

import android.content.Context;
import android.content.SharedPreferences;
import com.jw.dj.uploader.AppConfig;

public final class Prefs {
    private Prefs() {}

    public static SharedPreferences get(Context c) {
        return c.getSharedPreferences(AppConfig.PREFS, Context.MODE_PRIVATE);
    }

    public static String server(Context c) {
        String s = get(c).getString(AppConfig.PREF_SERVER, AppConfig.DEFAULT_SERVER);
        if (s == null || s.trim().isEmpty()) s = AppConfig.DEFAULT_SERVER;
        s = s.trim();
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    public static String uploadKey(Context c) {
        String s = get(c).getString(AppConfig.PREF_UPLOAD_KEY, "");
        return s == null ? "" : s.trim();
    }

    public static boolean paused(Context c) {
        return get(c).getBoolean(AppConfig.PREF_PAUSED, false);
    }

    public static void setPaused(Context c, boolean paused) {
        get(c).edit().putBoolean(AppConfig.PREF_PAUSED, paused).apply();
    }
}
