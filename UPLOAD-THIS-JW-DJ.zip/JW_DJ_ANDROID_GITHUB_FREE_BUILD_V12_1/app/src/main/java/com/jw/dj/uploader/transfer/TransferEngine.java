package com.jw.dj.uploader.transfer;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;

import com.jw.dj.uploader.AppConfig;
import com.jw.dj.uploader.data.QueueDatabase;
import com.jw.dj.uploader.data.QueueItem;
import com.jw.dj.uploader.net.JwApi;
import com.jw.dj.uploader.util.HashUtil;
import com.jw.dj.uploader.util.Prefs;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class TransferEngine {
    public interface Listener { void onProgress(String message, int percent); }

    private final Context context;
    private final QueueDatabase db;
    private final JwApi api;
    private final Listener listener;
    private volatile boolean stopRequested = false;

    public TransferEngine(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.db = new QueueDatabase(this.context);
        this.api = new JwApi(Prefs.server(this.context), Prefs.uploadKey(this.context));
        this.listener = listener;
    }

    public void requestStop() { stopRequested = true; }

    public void runUntilDone() {
        db.resetInterrupted();
        emit("Checking JW V11.9 cloud…", overallPercent());
        try {
            JwApi.Health h = api.health();
            if (h.uploadKeyRequired && Prefs.uploadKey(context).isEmpty()) {
                emit("JW cloud is online — enter the same Upload Key used in the DJ Downloads tab", overallPercent());
                return;
            }
        } catch (Exception e) {
            emit("JW cloud unavailable: " + clean(e), overallPercent());
            return;
        }

        while (!stopRequested && !Prefs.paused(context)) {
            List<QueueItem> pending = db.nextWork(AppConfig.TURBO_LANES);
            if (pending.isEmpty()) break;

            AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            boolean musicPlaying = am != null && am.isMusicActive();
            int lanes = musicPlaying ? AppConfig.PLAYING_LANES : AppConfig.TURBO_LANES;
            lanes = Math.max(1, Math.min(lanes, pending.size()));
            emit((musicPlaying ? "Music detected — 1 transfer lane" : "Turbo — " + lanes + " file lanes"), overallPercent());

            ExecutorService pool = Executors.newFixedThreadPool(lanes);
            List<Future<?>> futures = new ArrayList<>();
            for (int i = 0; i < lanes; i++) {
                QueueItem item = pending.get(i);
                futures.add(pool.submit(() -> process(item)));
            }
            for (Future<?> f : futures) { try { f.get(); } catch (Exception ignored) {} }
            pool.shutdown();

            if (db.countProcessing() > 0 && !stopRequested && !Prefs.paused(context)) sleep(5_000L);
        }

        if (Prefs.paused(context) || stopRequested) emit("Transfers paused — completed chunks are saved", overallPercent());
        else emit(db.countPending() == 0 ? "All queued files verified — SAFE TO DELETE count is current" : "Transfer pass finished", overallPercent());
    }

    private void process(QueueItem item) {
        if (stopRequested || Prefs.paused(context)) return;
        try {
            if ("PROCESSING".equals(item.status)) { checkProcessing(item); return; }
            if (item.size <= 0) throw new IllegalStateException("File is empty or size unavailable");

            if (item.transferId == null || item.transferId.isEmpty()) {
                db.setStatus(item.id, "HASHING", null);
                String transferId = HashUtil.transferId(item.relativePath, item.size, item.modified);
                int chunks = chunkCount(item.size);
                db.setTransfer(item.id, transferId, chunks);
                item.transferId = transferId; item.cloudId = transferId; item.totalChunks = chunks;
            }
            if (item.totalChunks <= 0) item.totalChunks = chunkCount(item.size);
            if (item.cloudId == null || item.cloudId.isEmpty()) item.cloudId = item.transferId;

            // First use the exact same filename/size duplicate lookup as V11.9 Phone Imports.
            emit("Checking cloud duplicate • " + item.name, overallPercent());
            JwApi.Duplicate dupe = retryDuplicate(item);
            if (dupe.duplicate && dupe.track != null && dupe.track.id != null && !dupe.track.id.isEmpty()) {
                item.cloudId = dupe.track.id; db.setCloudId(item.id, item.cloudId);
                if ("ready".equalsIgnoreCase(dupe.track.status)) {
                    verifyAndMark(item, item.cloudId, "Already in cloud");
                    return;
                }
                if ("processing".equalsIgnoreCase(dupe.track.status)) {
                    db.markProcessing(item.id, item.cloudId, stage(dupe.track));
                    emit("Already uploaded — cloud processing • " + item.name, overallPercent());
                    return;
                }
            }

            JwApi.Status st = retryStatus(item.transferId);
            if ("ready".equalsIgnoreCase(st.status)) { verifyAndMark(item, item.transferId, "Cloud copy ready"); return; }
            if ("processing".equalsIgnoreCase(st.status)) {
                db.setCloudId(item.id, item.transferId); db.markProcessing(item.id, item.transferId, stage(st.track));
                return;
            }

            Set<Integer> present = parseChunks(item.uploadedChunks);
            present.addAll(st.uploadedChunks);
            db.setUploadedChunks(item.id, chunksCsv(present));
            db.setStatus(item.id, "UPLOADING", null);
            uploadMissing(item, present, null);

            if (item.fingerprint == null || item.fingerprint.isEmpty()) {
                emit("Fingerprinting • " + item.name, overallPercent());
                item.fingerprint = HashUtil.quickFingerprint(context.getContentResolver(), Uri.parse(item.uri), item.size);
                db.setFingerprint(item.id, item.fingerprint);
            }

            db.setStatus(item.id, "VERIFYING", null);
            String[] parsed = parseName(item.name);
            JwApi.FinalizeResult finalized = finalizeWithRepair(item, present, parsed[0], parsed[1]);
            String cloudId = (finalized.track != null && finalized.track.id != null && !finalized.track.id.isEmpty()) ? finalized.track.id : item.transferId;
            item.cloudId = cloudId; db.setCloudId(item.id, cloudId);

            if (finalized.track != null && "ready".equalsIgnoreCase(finalized.track.status)) {
                verifyAndMark(item, cloudId, "Cloud verified");
                return;
            }

            retryStartProcessing(cloudId);
            db.markProcessing(item.id, cloudId, finalized.track == null ? "Cloud conversion queued" : stage(finalized.track));
            emit("Uploaded — cloud processing • " + item.name, overallPercent());
        } catch (Exception e) {
            db.setStatus(item.id, "ERROR", clean(e));
            emit("Retry saved • " + item.name + " • " + clean(e), overallPercent());
        }
    }

    private void checkProcessing(QueueItem item) throws Exception {
        String id = (item.cloudId == null || item.cloudId.isEmpty()) ? item.transferId : item.cloudId;
        if (id == null || id.isEmpty()) { db.setStatus(item.id, "QUEUED", null); return; }
        JwApi.Status s = retryStatus(id);
        if ("ready".equalsIgnoreCase(s.status)) { verifyAndMark(item, id, "Cloud processing complete"); return; }
        if ("failed".equalsIgnoreCase(s.status)) {
            String err = s.track != null && s.track.error != null && !s.track.error.isEmpty() ? s.track.error : "Cloud conversion failed";
            db.setStatus(item.id, "ERROR", err); return;
        }
        if ("processing".equalsIgnoreCase(s.status)) {
            db.markProcessing(item.id, id, stage(s.track));
            emit("Cloud processing • " + item.name + (s.track != null && s.track.progress > 0 ? " • " + s.track.progress + "%" : ""), overallPercent());
            return;
        }
        // If the track vanished but we still have the phone file, return to resumable upload status.
        db.setCloudId(item.id, item.transferId); db.setStatus(item.id, "QUEUED", null);
    }

    private void uploadMissing(QueueItem item, Set<Integer> present, Set<Integer> only) throws Exception {
        byte[] buffer = new byte[AppConfig.CHUNK_BYTES];
        try (InputStream in = context.getContentResolver().openInputStream(Uri.parse(item.uri))) {
            if (in == null) throw new IllegalStateException("Cannot reopen source file");
            for (int index = 0; index < item.totalChunks; index++) {
                if (stopRequested || Prefs.paused(context)) { db.setStatus(item.id, "PAUSED", null); return; }
                int expected = (int)Math.min(AppConfig.CHUNK_BYTES, item.size - ((long)index * AppConfig.CHUNK_BYTES));
                int len = readFully(in, buffer, expected);
                if (len != expected) throw new IllegalStateException("Source file changed while uploading");
                boolean wanted = only == null || only.contains(index);
                if (wanted && !present.contains(index)) {
                    uploadChunkWithRetry(item.transferId, item.name, index, buffer, len);
                    present.add(index); db.setUploadedChunks(item.id, chunksCsv(present));
                }
                int pct=(int)(((index+1L)*100L)/item.totalChunks);
                emit("Uploading " + item.name + " • " + pct + "%", overallPercent());
            }
        }
    }

    private JwApi.FinalizeResult finalizeWithRepair(QueueItem item, Set<Integer> present, String title, String artist) throws Exception {
        Exception last = null;
        for (int attempt=1; attempt<=7; attempt++) {
            try {
                return api.finalizeUpload(item.transferId,item.name,item.relativePath,item.mime,item.size,item.totalChunks,title,artist,item.modified,item.fingerprint);
            } catch (JwApi.ApiException e) {
                last=e;
                if (e.status==409) {
                    Set<Integer> missing=e.missingChunks();
                    if (!missing.isEmpty()) { for(Integer m:missing) present.remove(m); uploadMissing(item,present,missing); continue; }
                }
                if (e.status==400 || e.status==401 || e.status==403 || e.status==413) throw e;
            } catch (Exception e) { last=e; }
            sleep(Math.min(5_000L,350L*(1L<<Math.min(5,attempt-1))));
        }
        throw last==null?new IllegalStateException("Could not finalize upload"):last;
    }

    private JwApi.Duplicate retryDuplicate(QueueItem item) throws Exception { Exception last=null; for(int a=1;a<=3;a++){try{return api.duplicate(item.name,item.size);}catch(Exception e){last=e;sleep(a*600L);}} throw last; }
    private JwApi.Status retryStatus(String id) throws Exception { Exception last=null; for(int a=1;a<=4;a++){try{return api.status(id);}catch(Exception e){last=e;sleep(a*750L);}} throw last; }
    private void retryStartProcessing(String id) throws Exception { Exception last=null; for(int a=1;a<=4;a++){try{api.startProcessing(id);return;}catch(Exception e){last=e;sleep(a*1000L);}} throw last; }
    private void uploadChunkWithRetry(String id,String name,int index,byte[]bytes,int len) throws Exception { Exception last=null; for(int a=1;a<=5;a++){try{api.uploadChunk(id,index,bytes,len);return;}catch(Exception e){last=e;emit("Retrying chunk "+(index+1)+" • "+name,overallPercent());sleep(Math.min(12_000L,a*a*750L));}} throw last; }

    private void verifyAndMark(QueueItem item,String cloudId,String prefix) throws Exception {
        api.verifyMedia(cloudId); db.setCloudId(item.id,cloudId); db.markVerified(item.id);
        emit(prefix + " — SAFE TO DELETE • " + item.name, overallPercent());
    }

    private String stage(JwApi.Track t){if(t==null)return "Cloud processing";String s=t.processingStage;return(s==null||s.isEmpty())?"Cloud processing":s;}
    private String[] parseName(String name){String base=name==null?"Unknown":name.replaceFirst("\\.[^.]+$","").replace('_',' ').trim();String artist="Unknown Artist",title=base;int i=base.indexOf(" - ");if(i>0){artist=base.substring(0,i).trim();title=base.substring(i+3).trim();if(title.isEmpty())title=base;}return new String[]{title,artist};}
    private int overallPercent(){int all=db.countAll();if(all<=0)return 0;return Math.min(100,(db.countVerified()*100)/all);}
    private int chunkCount(long size){return(int)Math.max(1L,(size+AppConfig.CHUNK_BYTES-1L)/AppConfig.CHUNK_BYTES);}
    private int readFully(InputStream in,byte[]buffer,int expected)throws Exception{int offset=0;while(offset<expected){int n=in.read(buffer,offset,expected-offset);if(n<0)break;offset+=n;}return offset;}
    private Set<Integer> parseChunks(String csv){Set<Integer>s=new HashSet<>();if(csv==null||csv.trim().isEmpty())return s;for(String p:csv.split(",")){try{s.add(Integer.parseInt(p.trim()));}catch(Exception ignored){}}return s;}
    private String chunksCsv(Set<Integer>set){List<Integer>list=new ArrayList<>(set);Collections.sort(list);StringBuilder sb=new StringBuilder();for(int i=0;i<list.size();i++){if(i>0)sb.append(',');sb.append(list.get(i));}return sb.toString();}
    private void sleep(long ms){try{Thread.sleep(ms);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
    private void emit(String message,int percent){String m=progressPrefix()+message;if(listener!=null)listener.onProgress(m,percent);Intent i=new Intent(AppConfig.ACTION_PROGRESS);i.setPackage(context.getPackageName());i.putExtra(AppConfig.EXTRA_MESSAGE,m);i.putExtra("percent",percent);context.sendBroadcast(i);}
    private String progressPrefix(){int total=db.countAll(),safe=db.countVerified();return total>0?(safe+"/"+total+" verified • "):"";}
    private String clean(Exception e){String s=e.getMessage();return(s==null||s.trim().isEmpty())?e.getClass().getSimpleName():s;}
}
