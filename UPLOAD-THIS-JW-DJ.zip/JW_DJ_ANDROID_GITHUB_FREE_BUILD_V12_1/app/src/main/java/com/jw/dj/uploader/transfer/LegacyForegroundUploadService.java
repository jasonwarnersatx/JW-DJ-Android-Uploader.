package com.jw.dj.uploader.transfer;

import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import com.jw.dj.uploader.util.NotificationUtil;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LegacyForegroundUploadService extends Service {
    private ExecutorService executor;
    private TransferEngine engine;

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationUtil.ensureChannel(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NotificationUtil.NOTIFICATION_ID,
                    NotificationUtil.build(this, "Starting transfer…", 0, true),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NotificationUtil.NOTIFICATION_ID,
                    NotificationUtil.build(this, "Starting transfer…", 0, true));
        }
        executor = Executors.newSingleThreadExecutor();
        engine = new TransferEngine(this, (message, percent) -> {
            android.app.NotificationManager nm = (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NotificationUtil.NOTIFICATION_ID, NotificationUtil.build(this, message, percent, false));
        });
        executor.submit(() -> {
            try { engine.runUntilDone(); }
            finally { stopSelf(); }
        });
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (engine != null) engine.requestStop();
        if (executor != null) executor.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
