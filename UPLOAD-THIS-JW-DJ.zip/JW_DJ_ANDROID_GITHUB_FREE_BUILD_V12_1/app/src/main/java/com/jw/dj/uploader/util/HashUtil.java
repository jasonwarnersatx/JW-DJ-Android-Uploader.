package com.jw.dj.uploader.util;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

public final class HashUtil {
    private static final int FINGERPRINT_SPAN = 128 * 1024;
    private HashUtil() {}

    public static String transferId(String relativePath, long size, long modified) throws Exception {
        String text = String.valueOf(relativePath).toLowerCase(Locale.ROOT) + "|" + size + "|" + Math.max(0L, modified);
        MessageDigest d = MessageDigest.getInstance("SHA-256");
        String full = hex(d.digest(text.getBytes(StandardCharsets.UTF_8)));
        return full.substring(0, 32);
    }

    // Mirrors V11.9 bulk-upload.js quickFingerprint(): first 128 KB + |size| + last 128 KB.
    public static String quickFingerprint(ContentResolver resolver, Uri uri, long size) throws Exception {
        try (ParcelFileDescriptor pfd = resolver.openFileDescriptor(uri, "r")) {
            if (pfd != null) {
                try (FileInputStream in = new FileInputStream(pfd.getFileDescriptor()); FileChannel ch = in.getChannel()) {
                    byte[] head = readAt(ch, 0, (int)Math.min(FINGERPRINT_SPAN, Math.max(0L, size)));
                    long tailStart = Math.max(0L, size - FINGERPRINT_SPAN);
                    byte[] tail = readAt(ch, tailStart, (int)Math.min(FINGERPRINT_SPAN, Math.max(0L, size - tailStart)));
                    return fingerprint(head, tail, size);
                }
            }
        } catch (Exception ignored) {
            // Some document providers do not expose a seekable descriptor; use a streaming fallback.
        }
        return quickFingerprintStreaming(resolver, uri, size);
    }

    private static byte[] readAt(FileChannel ch, long position, int wanted) throws Exception {
        ByteBuffer b = ByteBuffer.allocate(Math.max(0, wanted)); ch.position(position);
        while (b.hasRemaining()) { int n=ch.read(b); if(n<0) break; }
        byte[] out=new byte[b.position()]; b.flip(); b.get(out); return out;
    }

    private static String quickFingerprintStreaming(ContentResolver resolver, Uri uri, long size) throws Exception {
        byte[] head; byte[] ring=new byte[FINGERPRINT_SPAN]; int ringCount=0, ringPos=0;
        try(InputStream in=resolver.openInputStream(uri)){
            if(in==null) throw new IllegalStateException("Unable to open file for fingerprint");
            ByteArrayOutputStream h=new ByteArrayOutputStream(FINGERPRINT_SPAN); byte[] buf=new byte[64*1024]; int n;
            while((n=in.read(buf))>0){
                int need=FINGERPRINT_SPAN-h.size(); if(need>0) h.write(buf,0,Math.min(need,n));
                for(int i=0;i<n;i++){ring[ringPos]=buf[i]; ringPos=(ringPos+1)%FINGERPRINT_SPAN; if(ringCount<FINGERPRINT_SPAN) ringCount++;}
            }
            head=h.toByteArray();
        }
        byte[] tail=new byte[ringCount];
        if(ringCount<FINGERPRINT_SPAN) System.arraycopy(ring,0,tail,0,ringCount);
        else {int a=FINGERPRINT_SPAN-ringPos;System.arraycopy(ring,ringPos,tail,0,a);System.arraycopy(ring,0,tail,a,ringPos);}
        // For files smaller than 128 KB the browser hashes the whole file twice (head and tail),
        // and the ring fallback above reproduces that behavior.
        return fingerprint(head,tail,size);
    }

    private static String fingerprint(byte[] head, byte[] tail, long size) throws Exception {
        MessageDigest d=MessageDigest.getInstance("SHA-256"); d.update(head); d.update(("|"+size+"|").getBytes(StandardCharsets.UTF_8)); d.update(tail); return hex(d.digest());
    }

    public static String hex(byte[] bytes){StringBuilder sb=new StringBuilder(bytes.length*2);for(byte b:bytes)sb.append(String.format("%02x",b));return sb.toString();}
}
