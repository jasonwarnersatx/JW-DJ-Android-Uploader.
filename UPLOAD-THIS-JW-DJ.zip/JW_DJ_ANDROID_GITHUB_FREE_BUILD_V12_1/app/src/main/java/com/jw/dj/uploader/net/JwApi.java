package com.jw.dj.uploader.net;

import com.jw.dj.uploader.AppConfig;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

public class JwApi {
    private final String base;
    private final String uploadKey;

    public JwApi(String base, String uploadKey) {
        String b = base == null ? AppConfig.DEFAULT_SERVER : base.trim();
        while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
        this.base = b;
        this.uploadKey = uploadKey == null ? "" : uploadKey.trim();
    }

    public Health health() throws Exception {
        JSONObject j = getJson("/.netlify/functions/cloud-health", false);
        Health h = new Health();
        h.ok = j.optBoolean("ok", true);
        h.uploadKeyRequired = j.optBoolean("uploadKeyRequired", false);
        h.message = j.optString("message", "JW V11.9 cloud backend online");
        return h;
    }

    public Duplicate duplicate(String name, long size) throws Exception {
        String path = "/.netlify/functions/cloud-api?op=duplicate&name=" + enc(name) + "&size=" + size;
        JSONObject j = getJson(path, true);
        Duplicate d = new Duplicate();
        d.duplicate = j.optBoolean("duplicate", false);
        JSONObject t = j.optJSONObject("track");
        if (t != null) d.track = Track.from(t);
        return d;
    }

    public Status status(String id) throws Exception {
        JSONObject j = getJson("/.netlify/functions/cloud-api?op=status&id=" + enc(id), true);
        Status s = new Status();
        s.status = j.optString("status", "missing");
        JSONArray a = j.optJSONArray("uploadedChunks");
        if (a != null) for (int i=0;i<a.length();i++) s.uploadedChunks.add(a.optInt(i));
        JSONObject t = j.optJSONObject("track");
        if (t != null) s.track = Track.from(t);
        return s;
    }

    public void uploadChunk(String id, int index, byte[] bytes, int length) throws Exception {
        HttpURLConnection c = open("POST", "/.netlify/functions/cloud-upload-chunk?id=" + enc(id) + "&index=" + index);
        auth(c);
        c.setRequestProperty("Content-Type", "application/octet-stream");
        c.setFixedLengthStreamingMode(length);
        c.setDoOutput(true);
        try {
            try (OutputStream out = c.getOutputStream()) { out.write(bytes, 0, length); }
            int code = c.getResponseCode();
            String body = readBody(c, code);
            if (code < 200 || code >= 300) throw apiError(code, body, "Chunk " + (index + 1) + " failed");
            if (body != null && !body.trim().isEmpty()) {
                try { JSONObject j = new JSONObject(body); if (j.has("error") && !j.isNull("error")) throw apiError(code, body, j.optString("error")); } catch (org.json.JSONException ignored) {}
            }
        } finally { c.disconnect(); }
    }

    public FinalizeResult finalizeUpload(String id, String name, String relativePath, String mime, long size,
                                         int chunks, String title, String artist, long lastModified,
                                         String fingerprint) throws Exception {
        JSONObject req = new JSONObject();
        req.put("id", id);
        req.put("name", name);
        req.put("relativePath", relativePath);
        req.put("mime", mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
        req.put("size", size);
        req.put("chunks", chunks);
        req.put("title", title);
        req.put("artist", artist);
        req.put("lastModified", lastModified);
        req.put("folder", AppConfig.PHONE_IMPORT_FOLDER);
        req.put("cloudFolder", AppConfig.PHONE_IMPORT_FOLDER);
        req.put("importSource", "phone-downloads");
        if (fingerprint != null && !fingerprint.isEmpty()) req.put("fingerprint", fingerprint);
        JSONObject j = postJson("/.netlify/functions/cloud-api?op=finalize", req, true);
        FinalizeResult r = new FinalizeResult();
        JSONObject t = j.optJSONObject("track");
        if (t != null) r.track = Track.from(t);
        return r;
    }

    public void startProcessing(String id) throws Exception {
        JSONObject body = new JSONObject(); body.put("id", id);
        postJson("/.netlify/functions/cloud-transcode-background", body, true, true);
    }

    public boolean verifyMedia(String id) throws Exception {
        String path = "/.netlify/functions/cloud-media?id=" + enc(id) + "&verify=" + System.currentTimeMillis();
        HttpURLConnection head = open("HEAD", path);
        try {
            int code = head.getResponseCode();
            if (code < 200 || code >= 300) throw new IllegalStateException("Cloud playback HEAD " + code);
        } finally { head.disconnect(); }

        HttpURLConnection get = open("GET", path);
        get.setRequestProperty("Range", "bytes=0-1023");
        try {
            int code = get.getResponseCode();
            if (code != 200 && code != 206) throw new IllegalStateException("Cloud playback probe " + code);
            try (InputStream in = get.getInputStream()) {
                byte[] one = new byte[1024]; int n = in.read(one);
                if (n <= 0) throw new IllegalStateException("Cloud playback probe returned no media");
            }
            return true;
        } finally { get.disconnect(); }
    }

    private JSONObject getJson(String path, boolean authenticated) throws Exception {
        HttpURLConnection c = open("GET", path); if (authenticated) auth(c);
        try { int code=c.getResponseCode(); String body=readBody(c,code); if(code<200||code>=300) throw apiError(code,body,"Cloud request failed"); return parseJson(body,code); }
        finally { c.disconnect(); }
    }

    private JSONObject postJson(String path, JSONObject json, boolean authenticated) throws Exception {
        return postJson(path, json, authenticated, false);
    }

    private JSONObject postJson(String path, JSONObject json, boolean authenticated, boolean allowEmpty) throws Exception {
        byte[] body = json.toString().getBytes(StandardCharsets.UTF_8);
        HttpURLConnection c = open("POST", path); c.setRequestProperty("Content-Type", "application/json; charset=utf-8"); if(authenticated) auth(c); c.setFixedLengthStreamingMode(body.length); c.setDoOutput(true);
        try {
            try(OutputStream out=c.getOutputStream()){out.write(body);} int code=c.getResponseCode(); String response=readBody(c,code);
            if(code<200||code>=300) throw apiError(code,response,"Cloud request failed");
            if(allowEmpty && (response==null||response.trim().isEmpty())) return new JSONObject();
            return parseJson(response,code);
        } finally { c.disconnect(); }
    }

    private JSONObject parseJson(String body, int code) throws Exception {
        JSONObject j = (body == null || body.trim().isEmpty()) ? new JSONObject() : new JSONObject(body);
        if (j.has("error") && !j.isNull("error") && !j.optString("error").isEmpty()) throw apiError(code, body, j.optString("error"));
        return j;
    }

    private ApiException apiError(int code, String body, String fallback) {
        JSONObject j = null; String message = fallback + " (HTTP " + code + ")";
        try { j = new JSONObject(body == null ? "{}" : body); String m=j.optString("error",""); if(!m.isEmpty()) message=m; } catch(Exception ignored) {}
        return new ApiException(code, message, j);
    }

    private void auth(HttpURLConnection c) { if (!uploadKey.isEmpty()) c.setRequestProperty("x-dj-upload-key", uploadKey); }

    private HttpURLConnection open(String method, String path) throws Exception {
        URL url = new URL(base + path); HttpURLConnection c=(HttpURLConnection)url.openConnection(); c.setRequestMethod(method); c.setConnectTimeout(30_000); c.setReadTimeout(120_000); c.setUseCaches(false); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("User-Agent","JW-DJ-Native-Uploader/12.1 Android V11.9-Compatible"); return c;
    }

    private String readBody(HttpURLConnection c, int code) throws Exception {
        InputStream raw = code >= 400 ? c.getErrorStream() : c.getInputStream(); if(raw==null)return "";
        try(BufferedInputStream in=new BufferedInputStream(raw);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[]buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString(StandardCharsets.UTF_8.name());}
    }

    private String enc(String s) throws Exception { return URLEncoder.encode(s == null ? "" : s, StandardCharsets.UTF_8.name()); }

    public static class ApiException extends Exception {
        public final int status; public final JSONObject data;
        public ApiException(int status,String message,JSONObject data){super(message);this.status=status;this.data=data;}
        public Set<Integer> missingChunks(){Set<Integer>out=new HashSet<>();if(data==null)return out;JSONArray a=data.optJSONArray("missing");if(a!=null)for(int i=0;i<a.length();i++)out.add(a.optInt(i));return out;}
    }
    public static class Health { public boolean ok; public boolean uploadKeyRequired; public String message; }
    public static class Duplicate { public boolean duplicate; public Track track; }
    public static class Status { public String status; public Track track; public Set<Integer> uploadedChunks=new HashSet<>(); }
    public static class FinalizeResult { public Track track; }
    public static class Track {
        public String id; public String status; public String processingStage; public int progress; public String title; public String artist; public String error;
        static Track from(JSONObject j){Track t=new Track();t.id=j.optString("id","");t.status=j.optString("status","");t.processingStage=j.optString("processingStage","");t.progress=j.optInt("progress",0);t.title=j.optString("title","");t.artist=j.optString("artist","");t.error=j.optString("error","");return t;}
    }
}
