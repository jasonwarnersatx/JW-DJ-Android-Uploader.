package com.jw.dj.uploader.transfer;

import android.app.Notification;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Build;

import com.jw.dj.uploader.util.NotificationUtil;
import com.jw.dj.uploader.util.Prefs;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class NativeTransferJobService extends JobService {
    private ExecutorService executor;
    private TransferEngine engine;

    @Override
    public boolean onStartJob(JobParameters params) {
        if (Build.VERSION.SDK_INT < 34) return false;
        executor = Executors.newSingleThreadExecutor();
        Notification start = NotificationUtil.build(this, "Starting transfer…", 0, true);
        setNotification(params, NotificationUtil.NOTIFICATION_ID, start, JOB_END_NOTIFICATION_POLICY_REMOVE);
        engine = new TransferEngine(this, (message, percent) -> {
            Notification n = NotificationUtil.build(this, message, percent, false);
            try { setNotification(params, NotificationUtil.NOTIFICATION_ID, n, JOB_END_NOTIFICATION_POLICY_REMOVE); }
            catch (Exception ignored) {}
        });
        executor.submit(() -> {
            try { engine.runUntilDone(); }
            finally { jobFinished(params, false); }
        });
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        if (engine != null) engine.requestStop();
        if (executor != null) executor.shutdownNow();
        return !Prefs.paused(this);
    }
}
