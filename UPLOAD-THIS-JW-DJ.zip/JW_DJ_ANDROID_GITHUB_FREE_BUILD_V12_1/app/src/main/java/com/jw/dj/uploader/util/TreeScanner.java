package com.jw.dj.uploader.util;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import com.jw.dj.uploader.data.QueueDatabase;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class TreeScanner {
    private TreeScanner() {}

    public interface Listener {
        void onProgress(int count, String latestName);
    }

    public static int scan(ContentResolver resolver, Uri treeUri, QueueDatabase db, Listener listener) throws Exception {
        String rootId = DocumentsContract.getTreeDocumentId(treeUri);
        return walk(resolver, treeUri, rootId, "", db, listener, new int[]{0}, new HashSet<>());
    }

    private static int walk(ContentResolver resolver, Uri treeUri, String parentId, String path,
                            QueueDatabase db, Listener listener, int[] count, Set<String> localDuplicateKeys) throws Exception {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId);
        String[] projection = new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
        };

        try (Cursor c = resolver.query(children, projection, null, null, null)) {
            if (c == null) return count[0];
            while (c.moveToNext()) {
                String docId = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                long size = c.isNull(3) ? 0L : c.getLong(3);
                long modified = c.isNull(4) ? 0L : c.getLong(4);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    walk(resolver, treeUri, docId, path + safe(name) + "/", db, listener, count, localDuplicateKeys);
                } else if (isPlayable(name, mime)) {
                    String displayName = name == null ? "Unknown" : name;
                    // Match V11.9 whole-folder behavior: collapse obvious Android duplicate copies
                    // such as "Song.mp3", "Song (1).mp3", and "Song copy.mp3" when file sizes match.
                    String duplicateKey = normalizeDuplicateName(displayName) + "|" + size;
                    if (!localDuplicateKeys.add(duplicateKey)) continue;

                    Uri fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                    db.upsertFile(fileUri.toString(), displayName,
                            path + displayName, size, mime, modified);
                    count[0]++;
                    if (listener != null) listener.onProgress(count[0], displayName);
                }
            }
        }
        return count[0];
    }

    public static boolean isPlayable(String name, String mime) {
        if (mime != null && (mime.startsWith("audio/") || mime.startsWith("video/"))) return true;
        if (name == null) return false;
        String s = name.toLowerCase(Locale.US);
        // Same extension family accepted by the V11.9 browser uploader.
        return s.endsWith(".mp3") || s.endsWith(".wav") || s.endsWith(".wave") ||
                s.endsWith(".m4a") || s.endsWith(".aac") || s.endsWith(".flac") ||
                s.endsWith(".ogg") || s.endsWith(".oga") || s.endsWith(".opus") ||
                s.endsWith(".webm") || s.endsWith(".aif") || s.endsWith(".aiff") ||
                s.endsWith(".caf") || s.endsWith(".mka") || s.endsWith(".wma") ||
                s.endsWith(".wv") || s.endsWith(".ape") || s.endsWith(".alac") ||
                s.endsWith(".ac3") || s.endsWith(".eac3") || s.endsWith(".dts") ||
                s.endsWith(".amr") || s.endsWith(".au") || s.endsWith(".snd") ||
                s.endsWith(".ra") || s.endsWith(".rm") || s.endsWith(".mp2") ||
                s.endsWith(".mpc") || s.endsWith(".tak") || s.endsWith(".tta") ||
                s.endsWith(".mp4") || s.endsWith(".m4v") || s.endsWith(".mov") ||
                s.endsWith(".mkv") || s.endsWith(".avi") || s.endsWith(".wmv") ||
                s.endsWith(".flv") || s.endsWith(".mpg") || s.endsWith(".mpeg") ||
                s.endsWith(".mpe") || s.endsWith(".ts") || s.endsWith(".mts") ||
                s.endsWith(".m2ts") || s.endsWith(".3gp") || s.endsWith(".3g2") ||
                s.endsWith(".ogv") || s.endsWith(".vob") || s.endsWith(".divx") ||
                s.endsWith(".asf") || s.endsWith(".rmvb");
    }

    private static String normalizeDuplicateName(String name) {
        String s = name == null ? "" : name.toLowerCase(Locale.US);
        s = s.replaceFirst("\\.[a-z0-9]{1,8}$", "");
        s = s.replaceFirst("\\s*\\(\\d+\\)\\s*$", "");
        s = s.replaceFirst("\\s*[-_ ]copy(?:[-_ ]?\\d+)?\\s*$", "");
        return s.replaceAll("\\s+", " ").trim();
    }

    private static String safe(String s) {
        return s == null ? "folder" : s.replace("/", "_");
    }
}
