package com.jw.dj.uploader.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class QueueDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "jw_upload_queue.db";
    private static final int DB_VERSION = 4;

    public QueueDatabase(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE queue (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "uri TEXT NOT NULL UNIQUE," +
                "name TEXT NOT NULL," +
                "relative_path TEXT," +
                "size INTEGER NOT NULL," +
                "mime TEXT," +
                "modified INTEGER," +
                "transfer_id TEXT," +
                "cloud_id TEXT," +
                "fingerprint TEXT," +
                "status TEXT NOT NULL DEFAULT 'QUEUED'," +
                "uploaded_chunks TEXT NOT NULL DEFAULT ''," +
                "total_chunks INTEGER NOT NULL DEFAULT 0," +
                "safe_delete INTEGER NOT NULL DEFAULT 0," +
                "error TEXT," +
                "created_at INTEGER NOT NULL," +
                "updated_at INTEGER NOT NULL" +
                ")");
        db.execSQL("CREATE INDEX idx_queue_status ON queue(status)");
        db.execSQL("CREATE INDEX idx_queue_transfer ON queue(transfer_id)");
        db.execSQL("CREATE INDEX idx_queue_cloud ON queue(cloud_id)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) { try { db.execSQL("ALTER TABLE queue ADD COLUMN modified INTEGER"); } catch (Exception ignored) {} }
        if (oldVersion < 3) {
            try { db.execSQL("ALTER TABLE queue ADD COLUMN transfer_id TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE queue ADD COLUMN cloud_id TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE queue ADD COLUMN fingerprint TEXT"); } catch (Exception ignored) {}
        }
        if (oldVersion < 4) {
            // Older prototype stored a full-file SHA in column sha256. V12.1 intentionally uses
            // V11.9's metadata-derived 32-character transfer ID, so stale prototype IDs are reset.
            try { db.execSQL("UPDATE queue SET transfer_id=NULL, cloud_id=NULL, fingerprint=NULL, uploaded_chunks='', total_chunks=0, safe_delete=0, status='QUEUED' WHERE safe_delete=0"); } catch (Exception ignored) {}
        }
    }

    public synchronized void upsertFile(String uri, String name, String relativePath, long size, String mime, long modified) {
        long now = System.currentTimeMillis(); SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery("SELECT id,size,modified,status FROM queue WHERE uri=?", new String[]{uri});
        try {
            if (c.moveToFirst()) {
                long oldSize=c.getLong(1), oldModified=c.getLong(2); String status=c.getString(3);
                ContentValues v=new ContentValues(); v.put("name",name); v.put("relative_path",relativePath); v.put("size",size); v.put("mime",mime); v.put("modified",modified); v.put("updated_at",now);
                if (oldSize!=size || oldModified!=modified) {
                    v.putNull("transfer_id"); v.putNull("cloud_id"); v.putNull("fingerprint"); v.put("status","QUEUED"); v.put("uploaded_chunks",""); v.put("total_chunks",0); v.put("safe_delete",0); v.putNull("error");
                } else if ("DELETED_LOCAL".equals(status)) { v.put("status","QUEUED"); v.put("safe_delete",0); }
                db.update("queue",v,"uri=?",new String[]{uri});
            } else {
                ContentValues v=new ContentValues(); v.put("uri",uri); v.put("name",name); v.put("relative_path",relativePath); v.put("size",size); v.put("mime",mime); v.put("modified",modified); v.put("status","QUEUED"); v.put("created_at",now); v.put("updated_at",now); db.insertOrThrow("queue",null,v);
            }
        } finally { c.close(); }
    }

    public synchronized List<QueueItem> nextWork(int limit) {
        List<QueueItem> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT * FROM queue WHERE status IN ('QUEUED','ERROR','HASHING','UPLOADING','PAUSED','VERIFYING','PROCESSING') AND safe_delete=0 ORDER BY CASE WHEN status='PROCESSING' THEN 1 ELSE 0 END, id LIMIT ?",new String[]{String.valueOf(limit)});
        try { while(c.moveToNext()) out.add(fromCursor(c)); } finally { c.close(); }
        return out;
    }

    public synchronized List<QueueItem> recent(int limit) { List<QueueItem> out=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT * FROM queue ORDER BY id DESC LIMIT ?",new String[]{String.valueOf(limit)}); try{while(c.moveToNext())out.add(fromCursor(c));}finally{c.close();} return out; }
    public synchronized List<QueueItem> safeItems() { List<QueueItem> out=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT * FROM queue WHERE safe_delete=1 AND status='VERIFIED' ORDER BY id",null); try{while(c.moveToNext())out.add(fromCursor(c));}finally{c.close();} return out; }

    public synchronized void setStatus(long id,String status,String error){ContentValues v=new ContentValues();v.put("status",status);v.put("updated_at",System.currentTimeMillis());if(error==null)v.putNull("error");else v.put("error",error);getWritableDatabase().update("queue",v,"id=?",new String[]{String.valueOf(id)});}
    public synchronized void setTransfer(long id,String transferId,int totalChunks){ContentValues v=new ContentValues();v.put("transfer_id",transferId);v.put("cloud_id",transferId);v.put("total_chunks",totalChunks);v.put("updated_at",System.currentTimeMillis());getWritableDatabase().update("queue",v,"id=?",new String[]{String.valueOf(id)});}
    public synchronized void setCloudId(long id,String cloudId){ContentValues v=new ContentValues();v.put("cloud_id",cloudId);v.put("updated_at",System.currentTimeMillis());getWritableDatabase().update("queue",v,"id=?",new String[]{String.valueOf(id)});}
    public synchronized void setFingerprint(long id,String fingerprint){ContentValues v=new ContentValues();v.put("fingerprint",fingerprint);v.put("updated_at",System.currentTimeMillis());getWritableDatabase().update("queue",v,"id=?",new String[]{String.valueOf(id)});}
    public synchronized void setUploadedChunks(long id,String csv){ContentValues v=new ContentValues();v.put("uploaded_chunks",csv==null?"":csv);v.put("updated_at",System.currentTimeMillis());getWritableDatabase().update("queue",v,"id=?",new String[]{String.valueOf(id)});}
    public synchronized void markProcessing(long id,String cloudId,String stage){ContentValues v=new ContentValues();v.put("cloud_id",cloudId);v.put("status","PROCESSING");v.put("error",stage==null?"Cloud conversion running":stage);v.put("updated_at",System.currentTimeMillis());getWritableDatabase().update("queue",v,"id=?",new String[]{String.valueOf(id)});}
    public synchronized void markVerified(long id){ContentValues v=new ContentValues();v.put("status","VERIFIED");v.put("safe_delete",1);v.putNull("error");v.put("updated_at",System.currentTimeMillis());getWritableDatabase().update("queue",v,"id=?",new String[]{String.valueOf(id)});}
    public synchronized void markLocalDeleted(long id){ContentValues v=new ContentValues();v.put("status","DELETED_LOCAL");v.put("safe_delete",0);v.put("updated_at",System.currentTimeMillis());getWritableDatabase().update("queue",v,"id=?",new String[]{String.valueOf(id)});}
    public synchronized void resetInterrupted(){ContentValues v=new ContentValues();v.put("status","QUEUED");v.put("updated_at",System.currentTimeMillis());getWritableDatabase().update("queue",v,"status IN ('HASHING','UPLOADING','PAUSED','VERIFYING') AND safe_delete=0",null);}
    public synchronized int countAll(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM queue WHERE status!='DELETED_LOCAL'",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
    public synchronized int countVerified(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM queue WHERE safe_delete=1",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
    public synchronized int countPending(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM queue WHERE safe_delete=0 AND status!='DELETED_LOCAL'",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
    public synchronized int countProcessing(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM queue WHERE safe_delete=0 AND status='PROCESSING'",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
    public synchronized long pendingBytes(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(size),0) FROM queue WHERE safe_delete=0 AND status!='DELETED_LOCAL'",null);try{return c.moveToFirst()?c.getLong(0):0L;}finally{c.close();}}

    private QueueItem fromCursor(Cursor c){QueueItem q=new QueueItem();q.id=c.getLong(c.getColumnIndexOrThrow("id"));q.uri=c.getString(c.getColumnIndexOrThrow("uri"));q.name=c.getString(c.getColumnIndexOrThrow("name"));q.relativePath=c.getString(c.getColumnIndexOrThrow("relative_path"));q.size=c.getLong(c.getColumnIndexOrThrow("size"));q.mime=c.getString(c.getColumnIndexOrThrow("mime"));q.modified=c.getLong(c.getColumnIndexOrThrow("modified"));q.transferId=getOptional(c,"transfer_id");q.cloudId=getOptional(c,"cloud_id");q.fingerprint=getOptional(c,"fingerprint");q.status=c.getString(c.getColumnIndexOrThrow("status"));q.uploadedChunks=c.getString(c.getColumnIndexOrThrow("uploaded_chunks"));q.totalChunks=c.getInt(c.getColumnIndexOrThrow("total_chunks"));q.safeDelete=c.getInt(c.getColumnIndexOrThrow("safe_delete"))!=0;q.error=c.getString(c.getColumnIndexOrThrow("error"));q.createdAt=c.getLong(c.getColumnIndexOrThrow("created_at"));q.updatedAt=c.getLong(c.getColumnIndexOrThrow("updated_at"));return q;}
    private String getOptional(Cursor c,String name){int i=c.getColumnIndex(name);return i<0?null:c.getString(i);}
}
