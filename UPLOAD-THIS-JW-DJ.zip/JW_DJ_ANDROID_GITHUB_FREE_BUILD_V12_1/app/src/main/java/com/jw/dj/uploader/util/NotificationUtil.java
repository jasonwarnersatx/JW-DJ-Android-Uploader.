package com.jw.dj.uploader.util;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;

import com.jw.dj.uploader.MainActivity;

public final class NotificationUtil {
    public static final String CHANNEL_ID = "jw_uploads";
    public static final int NOTIFICATION_ID = 1207;

    private NotificationUtil() {}

    public static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "JW DJ Transfers", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Shows progress while JW DJ uploads music in the background");
            ch.enableLights(true);
            ch.setLightColor(Color.CYAN);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
    }

    public static Notification build(Context c, String text, int progress, boolean indeterminate) {
        ensureChannel(c);
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CHANNEL_ID)
                : new Notification.Builder(c);
        b.setContentTitle("JW DJ — Cloud Upload")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi)
                .setCategory(Notification.CATEGORY_PROGRESS)
                .setProgress(100, Math.max(0, Math.min(100, progress)), indeterminate);
        return b.build();
    }
}
