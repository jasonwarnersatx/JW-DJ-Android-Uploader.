package com.jw.dj.uploader;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.jw.dj.uploader.data.QueueDatabase;
import com.jw.dj.uploader.data.QueueItem;
import com.jw.dj.uploader.net.JwApi;
import com.jw.dj.uploader.transfer.TransferScheduler;
import com.jw.dj.uploader.util.NotificationUtil;
import com.jw.dj.uploader.util.Prefs;
import com.jw.dj.uploader.util.TreeScanner;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_TREE = 1001;
    private static final int REQ_NOTIFICATIONS = 1002;

    private QueueDatabase db;
    private ExecutorService io;
    private EditText serverBox;
    private EditText uploadKeyBox;
    private TextView folderText;
    private TextView statusText;
    private TextView statsText;
    private TextView queueText;
    private ProgressBar progress;
    private BroadcastReceiver receiver;

    private final int bg = Color.rgb(5, 8, 18);
    private final int panel = Color.rgb(16, 23, 39);
    private final int cyan = Color.rgb(66, 232, 255);
    private final int green = Color.rgb(85, 227, 140);
    private final int pink = Color.rgb(255, 80, 176);
    private final int muted = Color.rgb(175, 188, 210);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new QueueDatabase(this);
        io = Executors.newCachedThreadPool();
        NotificationUtil.ensureChannel(this);
        setContentView(buildUi());
        setupReceiver();
        requestNotificationPermissionIfNeeded();
        refreshUi();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(28));
        scroll.addView(root);

        TextView title = text("JW DJ NATIVE UPLOADER", 26, Color.WHITE, true);
        title.setLetterSpacing(.08f);
        root.addView(title);
        TextView sub = text("V12.1 • V11.9 DIRECT CLOUD • SCREEN-OFF • RESUME • DEDUPE", 12, cyan, true);
        sub.setPadding(0, dp(4), 0, dp(18));
        root.addView(sub);

        LinearLayout statusCard = card();
        statusText = text("Ready", 16, Color.WHITE, true);
        statusCard.addView(statusText);
        TextView note = text("Uploads run as a native Android transfer job. Your phone files are never deleted automatically.", 12, muted, false);
        note.setPadding(0, dp(7), 0, 0);
        statusCard.addView(note);
        root.addView(statusCard);

        root.addView(section("CLOUD CONNECTION"));
        serverBox = new EditText(this);
        serverBox.setText(Prefs.server(this));
        serverBox.setTextColor(Color.WHITE);
        serverBox.setHintTextColor(muted);
        serverBox.setSingleLine(true);
        serverBox.setTextSize(14);
        serverBox.setPadding(dp(12), dp(12), dp(12), dp(12));
        serverBox.setBackgroundColor(panel);
        root.addView(serverBox, matchWrap());

        uploadKeyBox = new EditText(this);
        uploadKeyBox.setText(Prefs.uploadKey(this));
        uploadKeyBox.setHint("Upload Key — same key as DJ Downloads tab (leave blank if unused)");
        uploadKeyBox.setTextColor(Color.WHITE);
        uploadKeyBox.setHintTextColor(muted);
        uploadKeyBox.setSingleLine(true);
        uploadKeyBox.setTextSize(14);
        uploadKeyBox.setPadding(dp(12), dp(12), dp(12), dp(12));
        uploadKeyBox.setBackgroundColor(panel);
        uploadKeyBox.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams keyParams = matchWrap();
        keyParams.topMargin = dp(8);
        root.addView(uploadKeyBox, keyParams);

        Button cloudTest = button("🧪 TEST JW CLOUD", cyan);
        cloudTest.setOnClickListener(v -> testCloud());
        root.addView(cloudTest, matchWrapTop());

        root.addView(section("MUSIC FOLDER"));
        folderText = text(folderLabel(), 13, muted, false);
        folderText.setPadding(dp(12), dp(12), dp(12), dp(12));
        folderText.setBackgroundColor(panel);
        root.addView(folderText, matchWrap());

        LinearLayout row1 = row();
        Button choose = button("📁 SELECT FOLDER", cyan);
        Button scan = button("🔎 SCAN + QUEUE", pink);
        choose.setOnClickListener(v -> chooseFolder());
        scan.setOnClickListener(v -> scanFolder());
        row1.addView(choose, weight());
        row1.addView(scan, weight());
        root.addView(row1, matchWrapTop());

        root.addView(section("TRANSFER CONTROL"));
        LinearLayout row2 = row();
        Button start = button("▶ START / RESUME", green);
        Button pause = button("⏸ PAUSE", Color.rgb(255, 202, 80));
        start.setOnClickListener(v -> startTransfers());
        pause.setOnClickListener(v -> pauseTransfers());
        row2.addView(start, weight());
        row2.addView(pause, weight());
        root.addView(row2, matchWrap());

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(cyan));
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(12)) {{ topMargin = dp(14); }});

        statsText = text("", 14, Color.WHITE, true);
        statsText.setPadding(0, dp(10), 0, 0);
        root.addView(statsText);

        Button deleteSafe = button("🗑 DELETE ONLY SAFE-TO-DELETE FILES", green);
        deleteSafe.setOnClickListener(v -> confirmDeleteSafe());
        root.addView(deleteSafe, matchWrapTop());

        root.addView(section("QUEUE / VERIFICATION"));
        queueText = text("No files queued yet.", 12, muted, false);
        queueText.setTypeface(Typeface.MONOSPACE);
        queueText.setPadding(dp(12), dp(12), dp(12), dp(12));
        queueText.setBackgroundColor(panel);
        root.addView(queueText, matchWrap());

        TextView footer = text("Turbo automatically uses 4 upload lanes when no music is playing and drops to 1 lane when Android reports active music playback.", 11, muted, false);
        footer.setPadding(0, dp(18), 0, 0);
        root.addView(footer);
        return scroll;
    }

    private void setupReceiver() {
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String m = intent.getStringExtra(AppConfig.EXTRA_MESSAGE);
                int pct = intent.getIntExtra("percent", 0);
                if (m != null) statusText.setText(m);
                progress.setProgress(pct);
                refreshUi();
            }
        };
        IntentFilter f = new IntentFilter(AppConfig.ACTION_PROGRESS);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
    }

    private void chooseFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(i, PICK_TREE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_TREE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
            Prefs.get(this).edit().putString(AppConfig.PREF_TREE_URI, uri.toString()).apply();
            folderText.setText(folderLabel());
            statusText.setText("Folder selected — press SCAN + QUEUE");
        }
    }

    private void scanFolder() {
        String raw = Prefs.get(this).getString(AppConfig.PREF_TREE_URI, null);
        if (raw == null) {
            toast("Select your music folder first");
            return;
        }
        statusText.setText("Scanning folder…");
        io.submit(() -> {
            try {
                int count = TreeScanner.scan(getContentResolver(), Uri.parse(raw), db,
                        (n, latest) -> runOnUiThread(() -> statusText.setText("Queued " + n + " • " + latest)));
                runOnUiThread(() -> {
                    statusText.setText("Scan complete — " + count + " playable files found");
                    refreshUi();
                });
            } catch (Exception e) {
                runOnUiThread(() -> statusText.setText("Folder scan failed: " + clean(e)));
            }
        });
    }

    private void testCloud() {
        saveServer();
        statusText.setText("Testing JW V11.9 cloud…");
        io.submit(() -> {
            try {
                JwApi.Health h = new JwApi(Prefs.server(this), Prefs.uploadKey(this)).health();
                String m;
                if (!h.ok) m = "Cloud answered but reported not ready";
                else if (h.uploadKeyRequired && Prefs.uploadKey(this).isEmpty()) m = "Cloud online — enter the same Upload Key used in the DJ Downloads tab";
                else m = (h.message == null || h.message.trim().isEmpty()) ? "JW V11.9 cloud backend online" : h.message;
                final String message = m;
                runOnUiThread(() -> statusText.setText("✅ " + message));
            } catch (Exception e) {
                runOnUiThread(() -> statusText.setText("❌ " + clean(e)));
            }
        });
    }

    private void startTransfers() {
        saveServer();
        requestNotificationPermissionIfNeeded();
        if (db.countPending() <= 0) {
            toast("Nothing is waiting to upload");
            return;
        }
        boolean ok = TransferScheduler.start(this);
        statusText.setText(ok ? "Upload job started — you can lock the screen" : "Android did not accept the transfer job");
        refreshUi();
    }

    private void pauseTransfers() {
        TransferScheduler.pause(this);
        statusText.setText("Paused — completed chunks are saved");
        refreshUi();
    }

    private void confirmDeleteSafe() {
        List<QueueItem> safe = db.safeItems();
        if (safe.isEmpty()) {
            toast("No verified SAFE TO DELETE files yet");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Delete verified phone copies?")
                .setMessage(safe.size() + " file(s) are verified in JW cloud. Only these green SAFE TO DELETE files will be removed from the selected phone folder.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete SAFE Files", (d, w) -> deleteSafeFiles())
                .show();
    }

    private void deleteSafeFiles() {
        statusText.setText("Deleting verified phone copies…");
        io.submit(() -> {
            int deleted = 0, failed = 0;
            for (QueueItem q : db.safeItems()) {
                try {
                    boolean ok = DocumentsContract.deleteDocument(getContentResolver(), Uri.parse(q.uri));
                    if (ok) { db.markLocalDeleted(q.id); deleted++; }
                    else failed++;
                } catch (Exception e) { failed++; }
            }
            int d = deleted, f = failed;
            runOnUiThread(() -> {
                statusText.setText("Deleted " + d + " verified phone file(s)" + (f > 0 ? " • " + f + " could not be deleted" : ""));
                refreshUi();
            });
        });
    }

    private void saveServer() {
        String s = serverBox.getText().toString().trim();
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        String key = uploadKeyBox == null ? "" : uploadKeyBox.getText().toString().trim();
        Prefs.get(this).edit()
                .putString(AppConfig.PREF_SERVER, s)
                .putString(AppConfig.PREF_UPLOAD_KEY, key)
                .apply();
    }

    private void refreshUi() {
        int total = db.countAll();
        int safe = db.countVerified();
        int pending = db.countPending();
        statsText.setText("Library queue: " + total + "   •   Waiting: " + pending + "   •   SAFE TO DELETE: " + safe);
        if (total > 0) progress.setProgress((safe * 100) / total);

        List<QueueItem> items = db.recent(60);
        if (items.isEmpty()) {
            queueText.setText("No files queued yet.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (QueueItem q : items) {
            String icon = q.safeDelete ? "✅" : ("ERROR".equals(q.status) ? "⚠" : "•");
            sb.append(icon).append(' ').append(q.name).append('\n');
            sb.append("   ").append(q.safeDelete ? "SAFE TO DELETE" : q.status);
            if (q.error != null && !q.error.isEmpty()) sb.append(" — ").append(q.error);
            sb.append("\n\n");
        }
        queueText.setText(sb.toString().trim());
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private String folderLabel() {
        String raw = Prefs.get(this).getString(AppConfig.PREF_TREE_URI, null);
        return raw == null ? "No folder selected" : "Selected: " + Uri.decode(raw);
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        l.setBackgroundColor(panel);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private TextView section(String s) {
        TextView t = text(s, 12, cyan, true);
        t.setLetterSpacing(.08f);
        t.setPadding(0, dp(20), 0, dp(8));
        return t;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(darken(color)));
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        return b;
    }

    private int darken(int c) {
        return Color.rgb(Math.max(20, Color.red(c) / 3), Math.max(24, Color.green(c) / 3), Math.max(32, Color.blue(c) / 3));
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams matchWrapTop() {
        LinearLayout.LayoutParams p = matchWrap(); p.topMargin = dp(8); return p;
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private String clean(Exception e) { return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage(); }

    @Override
    protected void onResume() { super.onResume(); refreshUi(); }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        if (io != null) io.shutdownNow();
        if (db != null) db.close();
        super.onDestroy();
    }
}
