@echo off
setlocal
set APP_HOME=%~dp0
set VERSION=9.6.0
set CACHE=%APP_HOME%.gradle-local
set DIST=%CACHE%\gradle-%VERSION%
set ZIP=%CACHE%\gradle-%VERSION%-bin.zip
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%CACHE%" mkdir "%CACHE%"
  echo Downloading official Gradle %VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%ZIP%'"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%CACHE%'"
  if errorlevel 1 exit /b 1
  del /q "%ZIP%"
)
call "%DIST%\bin\gradle.bat" %*
endlocal
