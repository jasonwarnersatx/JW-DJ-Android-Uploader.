# JW DJ Native Uploader V12.1 — V11.9 Direct Cloud

This Android companion app is built for the existing JW AI DJ PRO V11.9 cloud backend at:

`https://jwdjsystem.netlify.app`

## Why this package does NOT replace the Netlify DJ

The supplied V11.9 download is a built Netlify deploy. It contains the DJ web files and `netlify.toml`, but it does not contain the source code for the already-live `cloud-api`, `cloud-upload-chunk`, `cloud-media`, `cloud-transcode-background`, and other Netlify Functions.

Replacing the live site with a new source bundle containing only a second uploader backend would risk breaking the cloud functions that V11.9 already uses. V12.1 therefore talks directly to the existing V11.9 backend instead.

**Keep the current DJ website exactly as it is.**

## What V12.1 matches from V11.9

- Same JW cloud library.
- Same 3,584 KB upload chunk size.
- Same metadata-derived transfer ID used by the web Downloads uploader.
- Same filename + file-size duplicate lookup.
- Same resumable cloud status / uploaded-chunk lookup.
- Same finalize call and Phone Imports metadata.
- Same lightweight fingerprint format (first 128 KB + file size + last 128 KB, SHA-256).
- Same cloud transcode/background-processing start.
- Same playback verification requirement before a file becomes **SAFE TO DELETE**.
- Same optional `x-dj-upload-key` header used by the DJ Downloads tab.

## Android transfer behavior

- Select an entire Android folder once.
- Queue playable audio/video files in the folder and subfolders.
- 4 file lanes when Android reports no active music playback.
- 1 file lane while music is playing.
- Android 14+ uses a user-initiated transfer job with a persistent notification.
- Android 8–13 uses a foreground data-sync service with a persistent notification.
- Completed chunks remain recorded so interrupted transfers resume.
- Obvious local Android duplicate copies are collapsed by normalized filename + size before queueing, matching V11.9 whole-folder behavior.
- Duplicate cloud tracks are not uploaded again.
- Local phone files are never deleted automatically.
- **SAFE TO DELETE** is set only after the cloud media endpoint successfully answers a HEAD check and a byte-range playback probe.
- The green delete button only deletes rows already verified SAFE TO DELETE.

## Cloud connection fields

**JW DJ URL** defaults to:

`https://jwdjsystem.netlify.app`

**Upload Key** must be the same value used in the V11.9 DJ Downloads tab. If the live cloud does not require an upload key, leave it blank.

## Build the APK in Android Studio

1. Open this folder as an Android Studio project.
2. Let Android Studio install/sync the requested Android SDK/platform if necessary.
3. Choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.

## Build the APK with GitHub Actions

This project is ready for a repository build. The included workflow:

`.github/workflows/build-apk.yml`

installs Java, Android SDK platform 37, Gradle 9.6.0, builds the debug APK, and uploads the APK as a workflow artifact.

## First run

1. Install the APK.
2. Open **JW DJ Uploader**.
3. Leave the default JW DJ URL unless the site address changes.
4. Enter the same Upload Key used by the web DJ if your cloud requires it.
5. Tap **TEST JW CLOUD**.
6. Tap **SELECT FOLDER** and choose the folder containing your downloaded music/videos.
7. Tap **SCAN + QUEUE**.
8. Tap **START / RESUME**.
9. The persistent Android notification shows transfer progress. You can switch apps or lock the screen.
10. Do not delete originals until the app shows **SAFE TO DELETE**.

## Important safety rule

The uploader does not trust “upload completed” by itself. A row becomes SAFE TO DELETE only after the V11.9 cloud track is ready and actual cloud media can be read back.
