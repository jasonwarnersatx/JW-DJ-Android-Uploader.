# FREE APK BUILD — GitHub Actions

This repository builds the JW DJ Native Uploader V12.1 without paying for Android Studio or a Play Store account.

## What the build uses
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- JDK 17
- compileSdk / targetSdk 37
- Android Build Tools 36.0.0

These versions match Android's documented AGP 9.4 compatibility table.

## Free build path
Use a **public GitHub repository**. Standard GitHub-hosted Actions runners are free for public repositories.

1. Put the full contents of this project into the repository root.
2. Make sure `.github/workflows/build-apk.yml` is present.
3. Open the repository's **Actions** tab.
4. Open **Build JW DJ Uploader APK**.
5. Tap **Run workflow**.
6. When it finishes, open the completed run.
7. Under **Artifacts**, download **JW-DJ-Uploader-V12.1-APK**.
8. Extract that artifact ZIP. The installable file is `app-debug.apk`.
9. On Android, allow your Files/browser app to install unknown apps, then open the APK.

## Important
Do not upload this Android project to Netlify. The app connects to the existing JW DJ V11.9 cloud backend at `https://jwdjsystem.netlify.app`.

The Upload Key is entered at runtime in the Android app. It is NOT stored in this repository.
