# V11.9 Direct Backend Contract Used by V12.1

The V12.1 native uploader intentionally reuses the current V11.9 upload pipeline rather than creating a second cloud library.

- Health: `GET /.netlify/functions/cloud-health`
- Duplicate check: `GET /.netlify/functions/cloud-api?op=duplicate&name=...&size=...`
- Resume/status: `GET /.netlify/functions/cloud-api?op=status&id=...`
- Chunk upload: `POST /.netlify/functions/cloud-upload-chunk?id=...&index=...`
- Finalize: `POST /.netlify/functions/cloud-api?op=finalize`
- Start conversion: `POST /.netlify/functions/cloud-transcode-background`
- Playback verification: `HEAD/GET /.netlify/functions/cloud-media?id=...`
- Optional auth header: `x-dj-upload-key`
- Chunk size: `3,584 * 1,024 = 3,670,016 bytes`
- Import folder metadata: `Music/Phone Imports`

The phone copy is not considered safe merely because all chunks were sent. V12.1 waits for cloud readiness and performs a real media read-back probe before enabling deletion.
